import java.util.ArrayList;

public class ClubDeFabricantes {

    private ArrayList<Miembro> miembros;
    private Almacen a;
    public ClubDeFabricantes( ArrayList<Miembro> miembros, Almacen a){
        this.miembros = miembros;
        this.a = a;
    }
}
