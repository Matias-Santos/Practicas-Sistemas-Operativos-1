public class Jarra {
    int cantLitros = 10;

    public Jarra(int cantLitros){
        this.cantLitros=cantLitros;
    }
    public int getCantLitros() {
        return cantLitros;
    }
}
